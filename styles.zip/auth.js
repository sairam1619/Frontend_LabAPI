const API = "https://wsc4x1zhwi.execute-api.us-east-1.amazonaws.com/prod";
const clientId = "34iomfmlh36d47r52khmfrst2c";
const domain = "https://us-east-1xta1wfvas.auth.us-east-1.amazoncognito.com";
const redirect = window.location.origin;

function getToken() {
  return localStorage.getItem("token");
}

function startLogin() {
  window.location.href =
    domain +
    "/oauth2/authorize" +
    "?response_type=token" +
    "&client_id=" +
    clientId +
    "&scope=email+openid+profile" +
    "&prompt=login" +
    "&redirect_uri=" +
    redirect;
}

function saveToken() {
  const existingToken = getToken();

  if (existingToken) {
    return;
  }

  if (!window.location.hash) {
    startLogin();

    return;
  }

  const params = new URLSearchParams(window.location.hash.substring(1));

  /*
    USE ID TOKEN
    FOR API GATEWAY JWT AUTHORIZER
  */

  const token = params.get("id_token");

  if (token) {
    localStorage.setItem("token", token);

    window.history.replaceState(null, "", window.location.pathname);

    window.history.pushState(null, "", window.location.pathname);
  }
}

function username() {
  const token = getToken();

  if (!token) return "";

  try {
    const payload = JSON.parse(atob(token.split(".")[1]));

    return (
      payload.name || payload.email || payload["cognito:username"] || "User"
    );
  } catch {
    return "User";
  }
}

function cognitoLogoutRedirect() {
  return (
    domain +
    "/logout?client_id=" +
    clientId +
    "&logout_uri=" +
    encodeURIComponent(window.location.origin + "/logout-success.html")
  );
}

function logout() {
  sessionStorage.clear();

  localStorage.removeItem("token");

  localStorage.removeItem("pendingConsoleUrl");

  localStorage.removeItem("labEndTime");

  localStorage.removeItem("consoleOpened");

  localStorage.removeItem("activeLabName");

  localStorage.removeItem("activeSectionName");

  window.location.href = cognitoLogoutRedirect();
}
